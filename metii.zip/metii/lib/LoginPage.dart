import 'dart:async';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'dart:convert';
import 'package:metii/LoginResponseModel.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  var usernameController =TextEditingController();
  var passwordController =TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
            "Login Page",
            style: TextStyle(color: Colors.white, fontFamily: "FORTE", fontSize: 50)
        ),
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back), color: Colors.white,),
        backgroundColor: Colors.black,
      ),
      body: LoginUI(),
    );
  }

  LoginUI(){
    return Builder(
      builder: (context) => Stack(
        children: [
          Padding(
              padding: EdgeInsets.only(left: 20, top: 45),
          child: Text("Login",
          style: TextStyle(
            fontFamily: "FTL",
            fontSize: 55,
            color: Colors.purple[800],
          ),
          ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(left: 40,right: 40, top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Material(
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                        hintText: "Username",
                        icon: Padding(
                          padding: EdgeInsets.only(left: 15),
                          child: Icon(
                            Icons.perm_identity,
                            color: Colors.purple[800],
                          ),
                        )
                      ),
                      textInputAction: TextInputAction.next,
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        fontSize: 25
                      ),
                      controller: usernameController,
                    ),
                    elevation: 20,
                    borderRadius: BorderRadius.circular(15),
                    shadowColor: Colors.grey[200],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Material(
                    child: TextField(
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                          hintText: "Password",
                          icon: Padding(
                            padding: EdgeInsets.only(left: 15),
                            child: Icon(
                              Icons.lock_outline,
                              color: Colors.purple[800],
                            ),
                          )
                      ),
                      textInputAction: TextInputAction.done,
                      obscureText: true,
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                          fontSize: 25
                      ),
                      controller: passwordController,
                    ),
                    elevation: 20,
                    borderRadius: BorderRadius.circular(15),
                    shadowColor: Colors.grey[200],
                  ),
                  SizedBox(
                    height: 50,
                  ),

                  Padding(
                    padding: EdgeInsets.only(left: 60,right: 60),
                    child: Material(
                      elevation: 20,
                      borderRadius: BorderRadius.circular(15),
                      color: Colors.purple[800],
                      child: InkWell(
                        onTap: (){
                          sendLoginRequest(context: context, username: usernameController.text, password: passwordController.text);
                        },
                        child: Container(
                          height: 70,
                          child: Center(
                            child: Text("Login",
                              style: TextStyle(
                                fontFamily: "FTL",
                                fontSize: 30,
                                color: Colors.white,
                              ),
                            ),
                          ),

                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void sendLoginRequest({required BuildContext context, required String username,required String password}) async{
    var url = "http://welearnacademy.ir/flutter/api/?type=login";
    var body = Map<String,dynamic>();
    body["username"] = username;
    body["password"] = password;
    Response response = await post(Uri.parse(url), body: body);
    if(response.statusCode == 200){
      //successful
      var loginJson=json.decode(utf8.decode(response.bodyBytes));
      var model=LoginResponseModel(loginJson["result"], loginJson["message"]);
      if(model.result == 0){
        showMySnackBar(context, model.message);
      }else if(model.result == 1){
        showMySnackBar(context, model.message);
        Navigator.pop(context);
      }

    }
    else{
      //error
      showMySnackBar(context, "Error");
    }
  }

  void showMySnackBar(BuildContext context,String message){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(
            message,
            textAlign: TextAlign.center,
            textDirection: TextDirection.rtl,
            style: TextStyle(
                      fontFamily: "BNazanin",
                      fontSize: 25,
                    ),
          )
      )
    );
  }
}
