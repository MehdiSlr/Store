import 'dart:developer';

import 'package:flutter/material.dart';
import 'Product.dart';

typedef OnRemovePressed(int index);
class ShoppingBasketItem extends StatefulWidget {

  Product _product;
  int _count=0;
  int _index;
  OnRemovePressed _onRemovePressed;

  ShoppingBasketItem(
      this._product,
      this._onRemovePressed,
      this._index
  );

  @override
  State<ShoppingBasketItem> createState() => _ShoppingBasketItemState();

}

class _ShoppingBasketItemState extends State<ShoppingBasketItem> {
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Container(
        height: 200,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          textDirection: TextDirection.rtl,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget> [
            Padding(
              padding:EdgeInsets.only(right: 40, left: 20),
              child: Image.network(widget._product.imageUrl,
              width: 100,
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget> [
                Padding(
                  padding: EdgeInsets.only(top: 30,right: 20),
                  child: Text(
                      widget._product.productName,
                  style: TextStyle(
                    fontFamily: "BNazanin",
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.purple[800]
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(bottom: 70, right: 15),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: <Widget> [
                      GestureDetector(
                          child: Icon(Icons.add_circle, size: 20, color: Colors.purple[800],),
                        onTap: (){
                            Increment();
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(widget._count.toString(),
                        style: TextStyle(fontSize: 20),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      GestureDetector(
                        child: Icon(Icons.remove_circle ,size: 20, color: Colors.purple[800],),
                        onTap: (){
                          Decrement();
                        },
                      )
                    ],
                  ),
                )
              ],
            ),
            Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(top: 20, bottom: 35, left: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        GestureDetector(
                            child: Icon(Icons.delete),
                        onTap: (){
                              widget._onRemovePressed(widget._index);
                        },),
                        Text(widget._product.price,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.red
                        ),),
                      ],
                    ),
                  ),
                )
            )
          ],
        ),
      ),
    );
  }
  void Increment(){
    setState(() {
      widget._count++;
    });
  }

  void Decrement(){
    setState(() {
      if(widget._count==0){
        return;
      } else {
        widget._count--;
      }
    });
  }
}
