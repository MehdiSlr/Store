import 'package:flutter/material.dart';
import 'package:metii/ShoppingBasketData.dart';
import 'package:metii/ShoppingBasketItem.dart';
import 'package:metii/ShopBottomNavigator.dart';

class ShoppingBasket extends StatefulWidget {
  const ShoppingBasket({Key? key}) : super(key: key);

  @override
  State<ShoppingBasket> createState() => _ShoppingBasketState();
}

class _ShoppingBasketState extends State<ShoppingBasket> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          title: const Text(
              "Card",
              style: TextStyle(color: Colors.white, fontFamily: "FORTE", fontSize: 50)
          ),
          leading: IconButton(
            onPressed: (){
              Navigator.pop(context);
            }, icon: Icon(Icons.arrow_back), color: Colors.white,),
          backgroundColor: Colors.black
      ),

      body: BasketUI(),



      bottomNavigationBar: const ShopBottomNavigator(),
      floatingActionButton: FloatingActionButton(
        onPressed: (){

        },
        backgroundColor: Colors.purple[800],
        child: const Icon(Icons.add, color: Colors.white,),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

    );
  }


  BasketUI(){
    return Stack(
      children: [
          Padding(
            padding: EdgeInsets.only(bottom: 85),
            child: ListView.builder(
              itemCount: ShoppingBasketData.getInstance().basketItems.length,
              itemBuilder: (context,position) {
                return GestureDetector(
                  child: Padding(
                    child: ShoppingBasketItem(ShoppingBasketData.getInstance().basketItems[position], RemoveItem,position),
                    padding: EdgeInsets.only(left: 10,right: 10,top: 10),),
                );
              },
            ),
          ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Material(
            color: Colors.purple[800],
            child: InkWell(
              onTap: (){

              },
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 85,
                child: Center(
                  child: Text("Buy",
                  style: TextStyle(
                    fontFamily: "FTL",
                    fontSize: 35,
                    fontWeight: FontWeight.bold,
                    color: Colors.white
                  ),)
                  ,
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
  void RemoveItem(int index){
    setState(() {
      ShoppingBasketData.getInstance().basketItems.removeAt(index);
    });
  }
}