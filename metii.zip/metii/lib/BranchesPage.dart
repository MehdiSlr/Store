import 'package:flutter/material.dart';


class BranchesPage extends StatefulWidget {
  const BranchesPage({Key? key}) : super(key: key);

  @override
  State<BranchesPage> createState() => _BranchesPageState();
}

class _BranchesPageState extends State<BranchesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          title: const Text(
              "Store",
              style: TextStyle(color: Colors.white, fontFamily: "RM", fontSize: 50)
          ),
          leading: IconButton(
            onPressed: (){
              Navigator.pop(context);
            }, icon: Icon(Icons.arrow_back), color: Colors.white,),
          backgroundColor: Colors.black
      ),

    );
  }
}
