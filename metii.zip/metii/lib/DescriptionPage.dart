import 'package:flutter/material.dart';
import 'package:metii/ShoppingBasket.dart';
import 'package:metii/main.dart';
import 'Product.dart';
import 'package:metii/ShoppingBasketData.dart';

class DesciptoinPage extends StatelessWidget {

  var _product;
  DesciptoinPage(this._product);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
            "Store",
            style: TextStyle(color: Colors.white, fontFamily: "RM", fontSize: 50)
        ),
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back), color: Colors.white,),
        backgroundColor: Colors.black,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.shopping_basket),
          onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=> ShoppingBasket()));
          },)
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Align(
            child: Text(
                "کفشِ "+_product.productName,
              style: TextStyle(
                fontFamily: "BNazanin",
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 40,
              ),
            ),
            alignment: Alignment.center,
          ),
          Center(
            child: Image.network(_product.imageUrl, height: 230),
          ),
          Text(
           _product.price+" تومان",
            style: TextStyle(
              color: Colors.red,
              fontFamily: "Cam",
              fontSize: 30,
            ),
            textDirection: TextDirection.rtl,
          ),
          SizedBox(
            height: 40,
          ),
          Padding(
            padding: EdgeInsets.only(left: 45,right: 45),
            child: Text(
              _product.description,
              style: TextStyle(
                  color: Colors.black,
                  fontFamily: "BNazanin",
                  fontSize: 19,
                fontWeight: FontWeight.bold
              ),
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            child: Align(
              child: Padding(
                padding: EdgeInsets.only(bottom: 50),
                child: InkWell(
                  onTap: (){
                    print("Added to Card ${_product.productName}");
                    ShoppingBasketData.getInstance().basketItems.add(_product);
                    print(ShoppingBasketData.getInstance().basketItems.length);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.purple[800],
                      borderRadius: BorderRadius.all(Radius.circular(20))
                    ),
                  child: Center(
                    child: Text("Add to Cart",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,

                    ),),
                  ),
                  width: MediaQuery.of(context).size.width-100,
                  height: 70,
              ),
                ),
              ),
              alignment: Alignment.bottomCenter,
            ),
          )
        ],
      ),
    );
  }
}
