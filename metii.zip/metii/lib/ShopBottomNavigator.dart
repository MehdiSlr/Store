import 'package:flutter/material.dart';
import 'package:metii/LoginPage.dart';
import 'package:metii/ShoppingBasket.dart';
import 'main.dart';

class ShopBottomNavigator extends StatelessWidget {
  const ShopBottomNavigator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(

      color: Colors.black87,
      shape: CircularNotchedRectangle(),
      notchMargin: 5.0,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      child: Container(
        height: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween ,
          children: [
            Container(
              height: 50,
              width: MediaQuery.of(context).size.width/2-20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  IconButton(icon: Icon(Icons.home, color: Colors.white),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> MainMaterial()));
                  },),
                  IconButton(icon: Icon(Icons.person_outline, color: Colors.white),
                    onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                  )
                ],
              ),
            ),
            Container(
              height: 50,
              width: MediaQuery.of(context).size.width/2-20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Icon(Icons.search, color: Colors.white),
                  IconButton( icon: Icon(Icons.shopping_basket, color: Colors.white,),
                              onPressed: (){
                                  Navigator.of(context).push(
                                      PageRouteBuilder(
                                          transitionDuration: Duration(seconds: 1),
                                        pageBuilder: (BuildContext context,
                                            Animation<double> animation,
                                            Animation <double> secondAnimation){
                                            return ShoppingBasket();
                                        },
                                        transitionsBuilder: (BuildContext context,
                                            Animation<double> animation,
                                            Animation <double> secondAnimation,
                                            Widget child){
                                            return SlideTransition(
                                              child: child,
                                              position: Tween<Offset>(begin: Offset(1,0),end: Offset(0,0)).animate(CurvedAnimation(parent: animation, curve: Curves.fastOutSlowIn)),
                                            );
                                        }
                                      )
                                  );
                  },
                  )
                  //Icon(Icons.shopping_basket, color: Colors.white)
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
