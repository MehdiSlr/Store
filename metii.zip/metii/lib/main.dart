
import 'dart:convert';

import 'package:flutter/material.dart';
import 'ShopBottomNavigator.dart';
import 'package:http/http.dart';
import 'package:metii/Product.dart';
import 'DescriptionPage.dart';

void main() {
  runApp(const MainMaterial());
}

class MainMaterial extends StatelessWidget {
  const MainMaterial({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Store(),
    );
  }
}

class Store extends StatefulWidget {
  const Store({Key? key}) : super(key: key);

  @override
  State<Store> createState() => _StoreState();
}


class _StoreState extends State<Store> {
  List<Product> _items=[];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchItems();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
              "Store",
          style: TextStyle(color: Colors.white, fontFamily: "RM", fontSize: 50)
          ),
          leading:const Icon(Icons.menu, color: Colors.white,),
          backgroundColor: Colors.black
        ),

        body: Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
          child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 15,
              children: List.generate(_items.length, (int position) => generateItem(_items[position],context)),
          ),
        ),
        backgroundColor: Colors.grey,

        bottomNavigationBar: const ShopBottomNavigator(),
        floatingActionButton: FloatingActionButton(
          onPressed: main,
          backgroundColor: Colors.purple[800],
          child: const Icon(Icons.add, color: Colors.white,),
        ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  void fetchItems() async{
    var url = "https://api.npoint.io/287555697207f397675b";
    Response response = await get(Uri.parse(url));
    setState(() {
      var productJson = json.decode(utf8.decode(response.bodyBytes));
      for(var i in productJson){
        var productItem=Product(i["product_name"], i["id"], i["price"], i["image_url"], i["off"], i["description"]);
        _items.add(productItem);
      }
    });
  }
}

Card generateItem(Product product, context){
  return Card(
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.all(Radius.circular(30))),
    elevation: 4,
    child: InkWell(
      onTap: (){
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => DesciptoinPage(product),));
      },
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 120,
              height: 120,
              child: Image.network(product.imageUrl),
            ),
            Text(
              product.productName,
              style: TextStyle(
                  fontFamily: "BNazanin",
                  color: Colors.purple[800],
                  fontSize: 25,
                  fontWeight: FontWeight.bold
            ),
            ),
            Text(
              product.price,
              style: const TextStyle(
                  fontFamily: "BNazanin",
                  color: Colors.red,
                  fontSize: 20
              ),
            )
          ],
        ),
      ),
    ),
  );
}
